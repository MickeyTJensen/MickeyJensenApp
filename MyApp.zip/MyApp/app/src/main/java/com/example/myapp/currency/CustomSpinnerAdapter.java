package com.example.myapp.currency;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapp.R;

import java.util.ArrayList;
import java.util.List;

public class CustomSpinnerAdapter extends ArrayAdapter<CurrencyItem> {
    private Context context;
    private List<CurrencyItem> currencyItems;
    private LayoutInflater inflater;

    public CustomSpinnerAdapter(Context context, ArrayList<CurrencyItem> currencyItems){
        super(context, R.layout.spinner_item, currencyItems);
        this.context = context;
        this.currencyItems = currencyItems;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {
        View row = inflater.inflate(R.layout.spinner_item, parent, false);
        TextView label = row.findViewById(R.id.currencyCodeTextView);
        ImageView icon = row.findViewById(R.id.flagImageView);

        CurrencyItem currencyItem = currencyItems.get(position);
        label.setText(currencyItem.getCurrencyCode());
        icon.setImageResource(currencyItem.getFlagImageId());

        return row;
    }
}

