package com.example.myapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.core.app.NotificationManagerCompat;

import com.example.myapp.mediaplayer.MediaPlayerManager;
import com.example.myapp.timer.TimerStopWatchActivity;

public class DismissReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("com.example.myapp.STOP_ALARM".equals(intent.getAction())) {
            MediaPlayerManager mediaPlayerManager = new MediaPlayerManager(context);
            mediaPlayerManager.stopAlarm();

            Log.d("DismissReceiver", "Stop action received at: " + System.currentTimeMillis());


            // Cancel the notification
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);
            notificationManager.cancel(TimerStopWatchActivity.NOTIFICATION_ID);
        }
    }
}