package com.example.myapp.currency;

public class CurrencyItem {
    private String currencyCode;
    private int flagImageId;

    public CurrencyItem(String currencyCode, int flagImageId) {
        this.currencyCode = currencyCode;
        this.flagImageId = flagImageId;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public int getFlagImageId() {
        return flagImageId;
    }
}
