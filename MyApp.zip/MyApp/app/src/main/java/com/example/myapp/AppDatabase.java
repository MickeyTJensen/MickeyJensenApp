package com.example.myapp;


import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.myapp.calendar.Event;
import com.example.myapp.calendar.EventDao;
import com.example.myapp.reminder.Reminder;
import com.example.myapp.reminder.ReminderDao;

@Database(entities = {Event.class, Reminder.class}, version = 2, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract EventDao eventDao();
    public abstract ReminderDao reminderDao();

    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Add a new column "new_column_name" to the "Reminder" table
            database.execSQL("ALTER TABLE reminders ADD COLUMN new_column_name INTEGER NOT NULL DEFAULT 0");
        }
    };
}

