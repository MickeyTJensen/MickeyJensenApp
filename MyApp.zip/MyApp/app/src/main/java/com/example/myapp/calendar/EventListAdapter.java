package com.example.myapp.calendar;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.myapp.AppDatabase;
import com.example.myapp.R;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class EventListAdapter extends ArrayAdapter<EventItem> {
    private Context context;
    private List<EventItem> eventItemList;
    private AppDatabase db;
    private OnEventDeleteListener deleteListener;

    public EventListAdapter(Context context, List<EventItem> eventItemList, AppDatabase db, OnEventDeleteListener deleteListener) {
        super(context, 0, eventItemList);
        this.context = context;
        this.eventItemList = eventItemList;
        this.db = db;
        this.deleteListener = deleteListener;
    }

    static class ViewHolder {
        TextView eventDetailsTextView;
        Button deleteButton;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;

        if (convertView == null) {
            LayoutInflater inflater = LayoutInflater.from(context);
            convertView = inflater.inflate(R.layout.list_item_event, parent, false);

            holder = new ViewHolder();
            holder.eventDetailsTextView = convertView.findViewById(R.id.eventDetailsTextView);
            holder.deleteButton = convertView.findViewById(R.id.deleteButton);

            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        EventItem event = getItem(position);
        if (event != null) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            String eventDetails = formatter.format(event.getDateTime()) + " " + event.getTitle();

            // Set the formatted string as the text of the TextView
            holder.eventDetailsTextView.setText(eventDetails);
        }

        holder.deleteButton.setOnClickListener(v -> {
            EventItem eventToRemove = getItem(position);
            if (eventToRemove != null) {
                deleteListener.onDeleteEvent(eventToRemove.getId());
                eventItemList.remove(eventToRemove);
                notifyDataSetChanged();
            }
        });

        return convertView;
    }
}