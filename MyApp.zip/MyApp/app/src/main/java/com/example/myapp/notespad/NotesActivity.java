package com.example.myapp.notespad;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.R;
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class NotesActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private List<Note> notes; // List to store notes

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        gridLayout = findViewById(R.id.gridLayoutNotes);
        ImageButton btnAddNote = findViewById(R.id.btnAddNote);

        btnAddNote.setOnClickListener(v -> {
            Note newNote = new Note(""); // Create a new note with empty content
            int uniqueId = (int) (System.currentTimeMillis() & 0xfffffff);
            newNote.setId(uniqueId);
            showEditNoteDialog(newNote); // Show dialog to edit this new note
        });


        notes = new ArrayList<>(); // Initialize the notes list
        loadNotes(); // Load notes and populate the GridLayout
    }

    private void refreshGridLayout(List<Note> notes) {
        gridLayout.removeAllViews(); // Clear existing views

        for (Note note : notes) {
            View noteView = LayoutInflater.from(this).inflate(R.layout.notes_item, gridLayout, false);

            // Apply the rounded background drawable
            noteView.setBackgroundResource(R.drawable.note_background);

            // Apply the note color as the background tint
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                noteView.getBackground().setTint(note.getColor());
            } else {
                // For older versions, a different approach to apply tint might be required
                // Consider using a compatible library or a custom solution
            }

            TextView tvNoteContent = noteView.findViewById(R.id.tvNoteContent);
            tvNoteContent.setText(note.getTitle());

            // Set OnClickListener for tvNoteContent
            tvNoteContent.setOnClickListener(v -> {
                showEditNoteDialog(note); // Open the dialog to edit this note
            });

            // Set OnClickListener for the delete button
            ImageButton btnDeleteNote = noteView.findViewById(R.id.btnDeleteNote);
            btnDeleteNote.setOnClickListener(v -> {
                deleteNote(note);
                refreshGridLayout(notes); // Refresh the grid after deletion
            });

            gridLayout.addView(noteView);
        }
    }
    private void saveNote() {
        Gson gson = new Gson();
        String notesJson = gson.toJson(notes);
        Log.d("NotesActivity", "Saving notes: " + notesJson);

        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("notes", notesJson);
        editor.apply();
    }
    private void loadNotes() {
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPrefs", MODE_PRIVATE);
        String notesJson = sharedPreferences.getString("notes", "");
        Log.d("NotesActivity", "Loaded notes: " + notesJson);

        if (!notesJson.isEmpty()) {
            Gson gson = new Gson();
            Type type = new TypeToken<List<Note>>() {}.getType();
            notes = gson.fromJson(notesJson, type);
        } else {
            notes = new ArrayList<>();
        }
        refreshGridLayout(notes);
    }

    private void showEditNoteDialog(Note note) {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.dialog_note_add);

        ImageButton btnColorGreen = dialog.findViewById(R.id.btnColorGreen);
        ImageButton btnColorYellow = dialog.findViewById(R.id.btnColorYellow);
        ImageButton btnColorPink = dialog.findViewById(R.id.btnColorPink);
        ImageButton btnColorBlue = dialog.findViewById(R.id.btnColorBlue);

        // Set up click listeners for each color button
        Consumer<Integer> updateColorSelection = selectedColor -> {
            btnColorGreen.setOnClickListener(v -> note.setColor(getResources().getColor(R.color.colorGreen)));
            btnColorYellow.setOnClickListener(v -> note.setColor(getResources().getColor(R.color.colorYellow)));
            btnColorPink.setOnClickListener(v -> note.setColor(getResources().getColor(R.color.colorPink)));
            btnColorBlue.setOnClickListener(v -> note.setColor(getResources().getColor(R.color.colorBlue)));
        };

        // Initially update the selection based on the current note color
        updateColorSelection.accept(note.getColor());

        // Set up click listeners for each color button
        btnColorGreen.setOnClickListener(v -> {
            note.setColor(getResources().getColor(R.color.colorGreen));
            updateColorSelection.accept(note.getColor());
        });
        btnColorYellow.setOnClickListener(v -> {
            note.setColor(getResources().getColor(R.color.colorYellow));
            updateColorSelection.accept(note.getColor());
        });
        btnColorPink.setOnClickListener(v -> {
            note.setColor(getResources().getColor(R.color.colorPink));
            updateColorSelection.accept(note.getColor());
        });
        btnColorBlue.setOnClickListener(v -> {
            note.setColor(getResources().getColor(R.color.colorBlue));
            updateColorSelection.accept(note.getColor());
        });

        // Adjust dialog width
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams();
        layoutParams.copyFrom(dialog.getWindow().getAttributes());
        int dialogWidth = (int) (getResources().getDisplayMetrics().widthPixels * 0.85);// 85% of screen width
        int dialogHeight = (int) (getResources().getDisplayMetrics().heightPixels * 0.85);
        layoutParams.width = dialogWidth;
        layoutParams.height = dialogHeight;
        dialog.getWindow().setAttributes(layoutParams);

        // Initialize dialog views
        EditText editTextNoteTitle = dialog.findViewById(R.id.editTextNoteTitle);
        EditText editTextNoteContent = dialog.findViewById(R.id.editTextNoteContent);
        Button btnSaveNote = dialog.findViewById(R.id.btnSaveNote);
        Button btnDeleteNote = dialog.findViewById(R.id.btnDeleteNote);

        // Set existing note data (if editing an existing note)
        editTextNoteTitle.setText(note.getTitle());
        editTextNoteContent.setText(note.getContent());



        // Handle save button click
        btnSaveNote.setOnClickListener(v -> {
            String title = editTextNoteTitle.getText().toString();
            String content = editTextNoteContent.getText().toString();

            // Update the note's title, content, and color
            note.setTitle(title);
            note.setContent(content);
            // Assume setColor is already handled by color button listeners

            // Update the note in the list
            updateNoteInList(note);

            // Now save the entire list
            saveNote();
            dialog.dismiss();

            // Refresh the grid layout to show updated note
            refreshGridLayout(notes);
        });


        dialog.getWindow().setBackgroundDrawableResource(R.drawable.dialog_background);
        dialog.getWindow().setElevation(dpToPx(4)); // Set elevation for shadow
        dialog.show();
    }
    private String notesToJson(List<Note> notes) {
        Gson gson = new Gson();
        return gson.toJson(notes);
    }

    private List<Note> jsonToNotes(String json) {
        Gson gson = new Gson();
        Type type = new TypeToken<List<Note>>() {}.getType();
        return gson.fromJson(json, type);
    }
    private void deleteNote(Note note) {
        notes.remove(note); // Remove the note from the list
        saveNote(); // Save the updated list
        refreshGridLayout(notes); // Refresh the GridLayout
    }
    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
    private void updateNoteInList(Note updatedNote) {
        int index = -1;
        for (int i = 0; i < notes.size(); i++) {
            if (notes.get(i).getId() == updatedNote.getId()) {
                index = i;
                break;
            }
        }

        if (index != -1) {
            notes.set(index, updatedNote); // Update the note if it exists
        } else {
            notes.add(updatedNote); // Add new note
        }
    }
    private void updateButtonStyle(ImageButton button, boolean isSelected) {
        if (isSelected) {
            button.setBackgroundResource(R.drawable.color_button_selected);
        } else {
            button.setBackground(null); // Or set to default background
        }
    }
}