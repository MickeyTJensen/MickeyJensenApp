package com.example.myapp.calendar;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class EventItem {
    private int id;
    private String title;
    private LocalDateTime dateTime;
    private String location;
    private String note;
    private boolean isRecurring;

    // Constructor with all parameters
    public EventItem(int id, LocalDate date, LocalTime time, String title) {
        this.id = id;
        this.dateTime = LocalDateTime.of(date, time);
        this.title = title;
    }



    // Getters and setters

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }
}