package com.example.myapp.calendar;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.myapp.AppNotificationManager;

public class CalendarEventReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        // Handle calendar event notifications here
        String title = intent.getStringExtra("eventTitle");
        String date = intent.getStringExtra("eventDate");
        String time = intent.getStringExtra("eventTime");

        // Show the notification using AppNotificationManager
        AppNotificationManager notificationManager = new AppNotificationManager(context);
        notificationManager.showEventNotification(title, date, time);

        // You can also perform any other necessary actions for calendar event notifications.
    }
}