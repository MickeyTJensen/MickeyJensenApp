package com.example.myapp.calendar;

public interface OnEventDeleteListener {
    void onDeleteEvent(int eventId);
}
