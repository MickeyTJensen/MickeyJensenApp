package com.example.myapp.reminder;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "reminders")
public class Reminder {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private int hour;
    private int minute;
    private String days; // "MTWTFSS" format, '1' for true, '0' for false
    private boolean isMorningReminder;
    private boolean isOneHourBefore;
    private boolean isActive;
    private String name;

    // Public constructor
    public Reminder(int id, int hour, int minute, String days, boolean isMorningReminder, boolean isOneHourBefore, String name, boolean isActive) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.days = days;
        this.isMorningReminder = isMorningReminder;
        this.isOneHourBefore = isOneHourBefore;
        this.name = name;
        this.isActive = isActive;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getHour() { return hour; }
    public void setHour(int hour) { this.hour = hour; }
    public int getMinute() { return minute; }
    public void setMinute(int minute) { this.minute = minute; }
    public String getDays() { return days; }
    public void setDays(String days) { this.days = days; }
    public boolean isMorningReminder() { return isMorningReminder; }
    public void setMorningReminder(boolean morningReminder) { this.isMorningReminder = morningReminder; }
    public boolean isOneHourBefore() { return isOneHourBefore; }
    public void setOneHourBefore(boolean oneHourBefore) { this.isOneHourBefore = oneHourBefore; }
    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { this.isActive = active; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    // Utility methods
    public static String convertDaysArrayToString(boolean[] daysArray) {
        StringBuilder sb = new StringBuilder();
        for (boolean day : daysArray) {
            sb.append(day ? "1" : "0");
        }
        return sb.toString();
    }

    public boolean[] getDaysArray() {
        boolean[] daysArray = new boolean[7];
        for (int i = 0; i < 7; i++) {
            daysArray[i] = this.days.charAt(i) == '1';
        }
        return daysArray;
    }
    public String getDaysAsString() {
        String[] daysOfWeek = {"Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"};
        boolean[] daysArray = getDaysArray(); // Get the boolean array from your existing method
        StringBuilder result = new StringBuilder();

        for (int i = 0; i < daysArray.length; i++) {
            if (daysArray[i]) {
                result.append(daysOfWeek[i]);
                result.append(", ");
            }
        }

        // Remove the trailing ", " if any days were added
        if (result.length() > 2) {
            result.setLength(result.length() - 2);
        }

        return result.toString();
    }
}