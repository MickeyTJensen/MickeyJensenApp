package com.example.myapp.currency;

import android.os.AsyncTask;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;

public class CurrencyActivity extends AppCompatActivity {

    // UI Components
    private EditText amountEditText;
    private Spinner currencyFromSpinner;
    private Spinner currencyToSpinner;
    private TextView resultTextView;
    private ImageButton switchButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.currency_item); // make sure this is the correct layout

        // Initialize UI components
        amountEditText = findViewById(R.id.amountEditText);
        currencyFromSpinner = findViewById(R.id.currencyFromSpinner);
        currencyToSpinner = findViewById(R.id.currencyToSpinner);
        resultTextView = findViewById(R.id.resultTextView);
        switchButton = findViewById(R.id.switchButton);

        // Fetch and update currency list
        new FetchCurrenciesTask().execute();

        // Set up button listeners
        setupButtonListeners();
        setupListeners();
    }

    private void setupButtonListeners() {
        switchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switchCurrencies();  // This should only swap the selections between spinners
            }
        });
    }

    private void initiateConversion() {
        Object fromSelectedItem = currencyFromSpinner.getSelectedItem();
        Object toSelectedItem = currencyToSpinner.getSelectedItem();

        String fromCurrency = "";
        String toCurrency = "";

        if (fromSelectedItem instanceof CurrencyItem) {
            fromCurrency = ((CurrencyItem) fromSelectedItem).getCurrencyCode();
        }

        if (toSelectedItem instanceof CurrencyItem) {
            toCurrency = ((CurrencyItem) toSelectedItem).getCurrencyCode();
        }

        String amountStr = amountEditText.getText().toString();

        if (!amountStr.isEmpty() && !fromCurrency.isEmpty() && !toCurrency.isEmpty()) {
            // Proceed with conversion if all fields are valid
            new CurrencyConverterTask().execute(fromCurrency, toCurrency, amountStr);
        } else {
            // Show "0" or placeholder text if fields are not ready
            resultTextView.setText("0");
        }
    }


    private void setupListeners() {
        AdapterView.OnItemSelectedListener spinnerListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                initiateConversion(); // Trigger conversion update when item selected
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                resultTextView.setText("0"); // Default to "0" when no selection
            }
        };

        currencyFromSpinner.setOnItemSelectedListener(spinnerListener);
        currencyToSpinner.setOnItemSelectedListener(spinnerListener);

        amountEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                initiateConversion(); // Trigger conversion update when text changes
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void switchCurrencies() {
        int fromPosition = currencyFromSpinner.getSelectedItemPosition();
        int toPosition = currencyToSpinner.getSelectedItemPosition();
        currencyFromSpinner.setSelection(toPosition);
        currencyToSpinner.setSelection(fromPosition);
    }

    private class FetchCurrenciesTask extends AsyncTask<Void, Void, ArrayList<CurrencyItem>> {

        @Override
        protected ArrayList<CurrencyItem> doInBackground(Void... voids) {
            ArrayList<CurrencyItem> currencyList = new ArrayList<>();
            HttpURLConnection urlConnection = null;
            final String API_URL = "https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies.json";

            try {
                URL url = new URL(API_URL);
                urlConnection = (HttpURLConnection) url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder jsonResult = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonResult.append(line);
                }

                JSONObject responseObject = new JSONObject(jsonResult.toString());
                Iterator<String> keys = responseObject.keys();

                while (keys.hasNext()) {
                    String key = keys.next();
                    int flagId = getResources().getIdentifier(key.toLowerCase(), "drawable", getPackageName());
                    if (flagId != 0) { // Ensure that a drawable resource was found
                        currencyList.add(new CurrencyItem(key, flagId));
                    } else {
                        Log.e("CurrencyActivity", "No drawable found for: " + key);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace(); // Log or handle error appropriately
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }

            return currencyList;
        }

        @Override
        protected void onPostExecute(ArrayList<CurrencyItem> result) {
            super.onPostExecute(result);
            if (result != null && !result.isEmpty()) {
                updateSpinners(result);
            } else {
                resultTextView.setText("Failed to fetch currencies. Check your connection.");
            }
        }
    }

    private void updateSpinners(ArrayList<CurrencyItem> currencyList) {
        // Assuming your custom adapter is named CurrencyAdapter
        CustomSpinnerAdapter adapter = new CustomSpinnerAdapter(this, currencyList);
        currencyFromSpinner.setAdapter(adapter);
        currencyToSpinner.setAdapter(adapter);
    }

        private class CurrencyConverterTask extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                // Extracting parameters for API call
                final String fromCurrency = params[0]; // Correctly extracted from passed parameters
                final String toCurrency = params[1];   // Correctly extracted from passed parameters
                final String amountStr = params[2];    // Correctly extracted from passed parameters

                // Constructing the API URL
                final String API_URL = "https://cdn.jsdelivr.net/gh/fawazahmed0/currency-api@1/latest/currencies/" + fromCurrency + "/" + toCurrency + ".json";
                Log.d("CurrencyConverterTask", "Constructed API URL: " + API_URL);

                HttpURLConnection urlConnection = null;
                StringBuilder result = new StringBuilder();

                try {
                    URL url = new URL(API_URL);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    int responseCode = urlConnection.getResponseCode();

                    Log.d("CurrencyConverterTask", "HTTP Response Code: " + responseCode);

                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                        String line;
                        while ((line = reader.readLine()) != null) {
                            result.append(line);
                        }

                        Log.d("CurrencyConverterTask", "API Response: " + result);

                        JSONObject jsonResponse = new JSONObject(result.toString());
                        if (!jsonResponse.has(toCurrency)) {
                            return "Error: Conversion rate not found for " + toCurrency;
                        }

                        double conversionRate = jsonResponse.getDouble(toCurrency);
                        double amountToConvert;
                        try {
                            amountToConvert = Double.parseDouble(amountStr);
                        } catch (NumberFormatException e) {
                            Log.e("CurrencyConverterTask", "NumberFormatException for amount: " + amountStr, e);
                            return "Error: Invalid amount.";
                        }

                        return String.format("%.2f", amountToConvert * conversionRate);
                    } else {
                        String errorResponse = "HTTP Error: " + responseCode;
                        Log.e("CurrencyConverterTask", errorResponse);
                        return errorResponse;
                    }
                } catch (IOException | JSONException e) {
                    Log.e("CurrencyConverterTask", "Exception in doInBackground", e);
                    return "Error: " + e.getMessage();
                } finally {
                    if (urlConnection != null) {
                        urlConnection.disconnect();
                    }
                }
            }

            @Override
            protected void onPostExecute(String result) {
                Log.d("CurrencyConverterTask", "onPostExecute Result: " + result);

                // Check if the result indicates an error
                if (result.startsWith("Error") || result.startsWith("HTTP Error")) {
                    // Directly display the error message without attempting to parse it
                    resultTextView.setText(result);
                    Log.d("CurrencyConverterTask", "Displayed error: " + result);
                } else {
                    try {
                        // Replace commas with periods to handle different decimal separators
                        result = result.replace(",", ".");

                        // Attempt to parse and format the result only if it does not indicate an error
                        double value = Double.parseDouble(result);
                        String formattedResult = String.format("%.2f", value);

                        Object toSelectedItem = currencyToSpinner.getSelectedItem();
                        String toCurrencyCode = (toSelectedItem instanceof CurrencyItem) ? ((CurrencyItem) toSelectedItem).getCurrencyCode() : "";

                        String formattedText = getString(R.string.formatted_result_with_currency, formattedResult, toCurrencyCode);
                        resultTextView.setText(formattedText);
                        Log.d("CurrencyConverterTask", "Result displayed: " + formattedText);
                    } catch (NumberFormatException e) {
                        Log.e("CurrencyConverterTask", "Error formatting/displaying result", e);
                        resultTextView.setText(getString(R.string.error_formatting_result));
                    }
                }
            }

        }
}