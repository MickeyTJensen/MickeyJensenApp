package com.example.myapp.timer;


import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.NumberPicker;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapp.AppNotificationManager;
import com.example.myapp.DismissReceiver;
import com.example.myapp.R;
import com.example.myapp.mediaplayer.MediaPlayerManager;

import java.util.Locale;

public class TimerStopWatchActivity extends AppCompatActivity {


    private TextView timerText, stopwatchText;
    private Button startTimerButton, setTimerButton, resetTimerButton, startStopwatchButton, resetStopwatchButton;
    private CountDownTimer countDownTimer;
    private long initialTimeInMillis = 0; // Default 10 minutes
    private long timeLeftInMillis = initialTimeInMillis;
    private boolean timerRunning = false;
    private Handler stopwatchHandler = new Handler();
    private long stopwatchStartTime = 0L;
    private boolean stopwatchRunning = false;
    private static final String CHANNEL_ID = "timer_channel"; // Define your channel ID
    public static final int NOTIFICATION_ID = 1; // Define your notification ID

    private AppNotificationManager notificationManager;
    private MediaPlayerManager mediaPlayerManager;
    private BroadcastReceiver stopAlarmReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer_stopwatch);
        initializeUIComponents();
        initializeBroadcastReceiver();
        createNotificationChannel();
    }

    private void initializeUIComponents() {
        timerText = findViewById(R.id.timerText);
        stopwatchText = findViewById(R.id.stopwatchText);
        startTimerButton = findViewById(R.id.startTimerButton);
        setTimerButton = findViewById(R.id.setTimerButton);
        resetTimerButton = findViewById(R.id.resetTimerButton);
        startStopwatchButton = findViewById(R.id.startStopwatchButton);
        resetStopwatchButton = findViewById(R.id.resetStopwatchButton);

        setTimerButton.setOnClickListener(v -> showTimerSetDialog());
        startTimerButton.setOnClickListener(v -> toggleTimer());
        resetTimerButton.setOnClickListener(v -> resetTimer());
        startStopwatchButton.setOnClickListener(v -> toggleStopwatch());
        resetStopwatchButton.setOnClickListener(v -> resetStopwatch());

        mediaPlayerManager = new MediaPlayerManager(this);
        notificationManager = new AppNotificationManager(this);
    }

    private void initializeBroadcastReceiver() {
        stopAlarmReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("com.example.myapp.STOP_ALARM".equals(intent.getAction())) {
                    mediaPlayerManager.stopAlarm();
                    notificationManager.cancelNotification(NOTIFICATION_ID);
                }
            }
        };
        IntentFilter filter = new IntentFilter("com.example.myapp.STOP_ALARM");
        registerReceiver(stopAlarmReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            notificationManager.createNotificationChannel(CHANNEL_ID, "Timer Notifications", "Notifications for Timer App");
        }
    }
    private void showTimerSetDialog() {
        // Create a dialog to set the timer
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_set_timer, null);
        builder.setView(dialogView);

        // Initialize NumberPickers for hours and minutes
        final NumberPicker numberPickerHour = dialogView.findViewById(R.id.numberPickerHour);
        final NumberPicker numberPickerMinute = dialogView.findViewById(R.id.numberPickerMinute);
        numberPickerHour.setMaxValue(23);
        numberPickerHour.setMinValue(0);
        numberPickerMinute.setMaxValue(59);
        numberPickerMinute.setMinValue(0);

        builder.setPositiveButton("Set", (dialog, which) -> {
            int hours = numberPickerHour.getValue();
            int minutes = numberPickerMinute.getValue();
            timeLeftInMillis = (hours * 3600 + minutes * 60) * 1000L;

            if (timeLeftInMillis > 0) {
                updateTimerText();
                startTimerButton.setEnabled(true); // Enable the "Start" button
            } else {
                // Show a message indicating that the timer needs to be set
                Toast.makeText(this, "Please set the timer duration.", Toast.LENGTH_SHORT).show();
            }
        });

        // Set negative button to cancel
        builder.setNegativeButton("Cancel", null);
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void toggleTimer() {
        if (!timerRunning) {
            startTimer();
        } else {
            pauseTimer();
        }
    }

    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimerText();
            }

            public void onFinish() {
                timerRunning = false;
                startTimerButton.setText("Start");
                sendTimerNotification();
            }
        }.start();
        timerRunning = true;
        startTimerButton.setText("Pause");
    }

    private void pauseTimer() {
        countDownTimer.cancel();
        timerRunning = false;
        startTimerButton.setText("Start");
    }

    private void resetTimer() {
        timeLeftInMillis = 0; // Set time left to 0 instead of initialTimeInMillis
        updateTimerText(); // This will update the timer text to show 00:00:00
        if (timerRunning) {
            countDownTimer.cancel(); // Stop the countdown if it's running
        }
        timerRunning = false;
        startTimerButton.setText("Start");
        startTimerButton.setEnabled(false); // Optionally disable the start button since there's no time set
    }

    private void sendTimerNotification() {
        mediaPlayerManager.playAlarmSound();
        Log.d("TimerStopWatchActivity", "Alarm sound initiated at: " + System.currentTimeMillis());

        Intent dismissIntent = new Intent(this, DismissReceiver.class);
        dismissIntent.setAction("com.example.myapp.STOP_ALARM");
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(this, 0, dismissIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_IMMUTABLE);

        notificationManager.showTimerNotification(
                CHANNEL_ID,
                NOTIFICATION_ID,
                "Timer Finished",
                "Your timer has finished.",
                dismissPendingIntent // Pass the PendingIntent here
        );
    }

    private void updateTimerText() {
        int hours = (int) (timeLeftInMillis / 1000) / 3600;
        int minutes = (int) ((timeLeftInMillis / 1000) % 3600) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeFormatted = String.format(Locale.getDefault(), "%02d:%02d:%02d", hours, minutes, seconds);
        timerText.setText(timeFormatted);
    }

    // Stopwatch methods
    private void toggleStopwatch() {
        if (!stopwatchRunning) {
            startStopwatch();
        } else {
            pauseStopwatch();
        }
    }

    private void startStopwatch() {
        stopwatchStartTime = SystemClock.elapsedRealtime();
        stopwatchHandler.postDelayed(stopwatchRunnable, 0);
        stopwatchRunning = true;
        startStopwatchButton.setText("Stop");
    }

    private void pauseStopwatch() {
        stopwatchHandler.removeCallbacks(stopwatchRunnable);
        stopwatchRunning = false;
        startStopwatchButton.setText("Start");
    }

    private void resetStopwatch() {
        stopwatchHandler.removeCallbacks(stopwatchRunnable);
        stopwatchStartTime = 0L;
        stopwatchRunning = false;
        stopwatchText.setText("00:00:00");
        startStopwatchButton.setText("Start");
    }

    private final Runnable stopwatchRunnable = new Runnable() {
        public void run() {
            long elapsedMillis = SystemClock.elapsedRealtime() - stopwatchStartTime;
            int minutes = (int) (elapsedMillis / 60000);
            int seconds = (int) (elapsedMillis % 60000) / 1000;
            int milliseconds = (int) (elapsedMillis % 1000) / 10; // Dividing by 10 to get two digits for milliseconds

            // Update the stopwatch text to show minutes, seconds, and milliseconds
            stopwatchText.setText(String.format(Locale.getDefault(), "%02d:%02d:%02d", minutes, seconds, milliseconds));

            // Post the runnable again with a delay to update the stopwatch
            stopwatchHandler.postDelayed(this, 10);
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(stopAlarmReceiver);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent != null && "com.example.myapp.STOP_ALARM".equals(intent.getAction())) {
            mediaPlayerManager.stopAlarm();
            resetTimer();
        }
    }

    private void showSetTimerMessage() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Timer Expired");
        builder.setMessage("The timer has reached 00:00:00. Please set a new timer.");
        builder.setPositiveButton("OK", null);
        builder.create().show();
    }
}