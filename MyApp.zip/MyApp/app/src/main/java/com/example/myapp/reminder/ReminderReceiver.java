package com.example.myapp.reminder;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.example.myapp.AppNotificationManager;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if ("YOUR_REMINDER_ACTION".equals(intent.getAction())) {
            int reminderId = intent.getIntExtra("reminder_id", -1);
            String reminderName = intent.getStringExtra("reminder_name");
            // Assuming you moved sendReminderNotification to AppNotificationManager
            AppNotificationManager notificationManager = new AppNotificationManager(context);
            notificationManager.sendReminderNotification(context, reminderId, reminderName);
            Log.d("ReminderReceiver", "Triggering notification for reminder ID: " + reminderId + ", Name: " + reminderName);

        }
    }

}