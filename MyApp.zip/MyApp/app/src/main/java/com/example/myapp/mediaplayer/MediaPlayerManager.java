package com.example.myapp.mediaplayer;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.util.Log;

import com.example.myapp.R;

public class MediaPlayerManager {

    private Context context;
    private MediaPlayer mediaPlayer;
    private Handler handler = new Handler();
    private Runnable stopRunnable = () -> stopAlarm();

    public MediaPlayerManager(Context context) {
        this.context = context;
    }

    public void playAlarmSound() {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context, R.raw.alarm_sound);
            mediaPlayer.start();

            // Stop the sound after 20 seconds if not stopped earlier
            handler.postDelayed(stopRunnable, 20000); // 20 seconds
            Log.d("MediaPlayerManager", "Alarm sound started at: " + System.currentTimeMillis());
        }
    }

    public void stopAlarm() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
            handler.removeCallbacks(stopRunnable); // Remove the callback if alarm is stopped early
            Log.d("MediaPlayerManager", "Alarm sound stopped at: " + System.currentTimeMillis());
        }
    }
}