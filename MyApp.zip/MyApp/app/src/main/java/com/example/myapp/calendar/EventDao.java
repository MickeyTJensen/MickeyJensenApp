package com.example.myapp.calendar;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface EventDao {
    @Query("SELECT * FROM Event")
    List<Event> getAll();

    @Query("SELECT * FROM Event WHERE date = :date")
    List<Event> getEventsForDate(String date);

    @Insert
    long insert(Event event); // Returns the ID of the inserted event

    // If you need to insert multiple events at once and get all their IDs
    @Insert
    long[] insertAll(Event... events);

    @Delete
    void delete(Event event);

    @Query("SELECT * FROM Event WHERE id = :eventId")
    Event getEventById(int eventId);

}