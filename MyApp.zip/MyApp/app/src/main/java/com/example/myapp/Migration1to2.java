package com.example.myapp;

import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

public class Migration1to2 extends Migration {
    public Migration1to2() {
        super(1, 2);
    }

    @Override
    public void migrate(SupportSQLiteDatabase database) {
        // Create the new "Event" table
        database.execSQL(
                "CREATE TABLE IF NOT EXISTS `Event` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "`title` TEXT, " +
                        "`date` TEXT, " +
                        "`time` TEXT" +
                        ")"
        );
    }
}

