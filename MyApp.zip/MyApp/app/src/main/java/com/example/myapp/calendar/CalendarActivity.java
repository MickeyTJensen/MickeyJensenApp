package com.example.myapp.calendar;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import com.example.myapp.AlarmBroadcastReceiver;
import com.example.myapp.AppDatabase;
import com.example.myapp.Migration1to2;
import com.example.myapp.MyApp;
import com.example.myapp.R;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class CalendarActivity extends AppCompatActivity implements OnEventDeleteListener {
    private List<EventItem> events;
    private EventListAdapter eventListAdapter;
    private MaterialCalendarView materialCalendarView;
    private AppDatabase db;
    private LocalDate selectedDate;
    private LocalTime selectedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        db = ((MyApp) getApplication()).getDatabase();

        initializeDatabase();
        initializeViews();
        new LoadEventsTask().execute();

        // Set up the listener for date changes in MaterialCalendarView
        materialCalendarView.setOnDateChangedListener(new OnDateSelectedListener() {
            @Override
            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
                // Capture the selected date
                LocalDate javaDate = LocalDate.of(date.getYear(), date.getMonth(), date.getDay()); // Adjust month
                selectedDate = javaDate;

                Log.d("CalendarActivity", "Selected Date: " + selectedDate);

                // Fetch events for the selected date from the database
                List<Event> eventsForSelectedDate = db.eventDao().getEventsForDate(javaDate.toString());
                Log.d("CalendarActivity", "Events for Selected Date (from DB): " + eventsForSelectedDate);


                // Convert List<Event> to List<EventItem>
                List<EventItem> eventItemsForSelectedDate = new ArrayList<>();
                for (Event event : eventsForSelectedDate) {
                    EventItem eventItem = new EventItem(event.getId(), LocalDate.parse(event.getDate()), LocalTime.parse(event.getTime()), event.getTitle());
                    eventItemsForSelectedDate.add(eventItem);
                }

                // Update the event list UI with eventItemsForSelectedDate
                eventListAdapter.clear();
                eventListAdapter.addAll(eventItemsForSelectedDate);
                eventListAdapter.notifyDataSetChanged();
            }
        });
        updateCalendarWithEvents(db.eventDao().getAll());
    }

    @Override
    public void onDeleteEvent(int eventId) {
        deleteEventFromDatabase(eventId);
    }

    public interface OnEventDeleteListener {
        void onDeleteEvent(int eventId);
    }

    private void deleteEventFromDatabase(int eventId) {
        AsyncTask.execute(() -> {
            // Use the provided eventId to delete the Event
            Event event = db.eventDao().getEventById(eventId);
            if (event != null) {
                db.eventDao().delete(event);
                Log.d("DeleteEvent", "Event deleted from database: " + eventId);
                runOnUiThread(() -> new LoadEventsTask().execute()); // Refresh the events
                updateCalendarWithEvents(db.eventDao().getAll());
            } else {
                Log.d("DeleteEvent", "Event not found in database: " + eventId);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        new LoadEventsTask().execute();
    }

    private void initializeDatabase() {
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "calendar-database")
                .allowMainThreadQueries()
                .addMigrations(new Migration1to2()) // Add your migration class here
                .build();
    }

    private void initializeViews() {
        materialCalendarView = findViewById(R.id.calendarView);
        ListView eventListView = findViewById(R.id.eventListView);
        events = new ArrayList<>();

        // Create an instance of your AppDatabase
        AppDatabase appDatabase = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "my-database-name")
                .build();

        eventListAdapter = new EventListAdapter(this, events, appDatabase, this); // Use appDatabase here
        eventListView.setAdapter(eventListAdapter);

        // Find the "Add Event" button in your layout
        Button addEventButton = findViewById(R.id.addEventButton);

        // Set an OnClickListener for the "Add Event" button
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // When the button is clicked, display the "Add Event" dialog
                setupAddEventDialog();
            }
        });
    }

    private class LoadEventsTask extends AsyncTask<Void, Void, List<Event>> {
        @Override
        protected List<Event> doInBackground(Void... voids) {
            try {
                if (db != null) {
                    return db.eventDao().getAll();
                } else {
                    Log.e("LoadEventsTask", "Database instance is null");
                    return new ArrayList<>(); // Return an empty list or appropriate error handling
                }
            } catch (Exception e) {
                Log.e("LoadEventsTask", "Error accessing database", e);
                return new ArrayList<>(); // Return an empty list or appropriate error handling
            }
        }


        @Override
        protected void onPostExecute(List<Event> events) {
            if (events != null) {
                // Process the list of events
            } else {
                // Handle the case where events are null
                Log.e("CalendarActivity", "Failed to load events; the list is null.");
            }
        }
    }

    private void updateCalendarWithEvents(List<Event> dbEvents) {
        List<CalendarDay> eventDays = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        for (Event event : dbEvents) {
            try {
                String formattedDate = event.getDate().replaceFirst("-(\\d)-", "-0$1-");
                LocalDate date = LocalDate.parse(formattedDate, formatter);
                CalendarDay day = CalendarDay.from(date.getYear(), date.getMonthValue(), date.getDayOfMonth());
                eventDays.add(day);
            } catch (DateTimeParseException e) {
                e.printStackTrace();
            }
        }

        Log.d("UpdateCalendar", "Event Days: " + eventDays);

        // Clear existing decorators before adding the new ones
        materialCalendarView.removeDecorators();

        // Add the new decorators to the MaterialCalendarView
        materialCalendarView.addDecorator(new EventDecorator(Color.RED, eventDays));
    }


    public void scheduleCalendarEventNotifications(Event event) {
        LocalDateTime eventDateTime = LocalDateTime.of(
                LocalDate.parse(event.getDate()), LocalTime.parse(event.getTime())
        );
        LocalDateTime notificationTime1 = eventDateTime.withHour(7).withMinute(0);
        LocalDateTime notificationTime2 = eventDateTime.minusHours(1);

        Log.d("CalendarActivity", "Scheduling notifications for Event ID: " + event.getId());
        scheduleNotification(event.getId(), notificationTime1, "07:00 Notification", event);
        scheduleNotification(event.getId(), notificationTime2, "1 Hour Before Notification", event);
    }

    private void scheduleNotification(int eventId, LocalDateTime notificationTime, String notificationContent, Event event) {

        // Use Swedish time zone for scheduling
        ZoneId swedenZoneId = ZoneId.of("Europe/Stockholm");
        long notificationMillis = notificationTime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
        Log.d("CalendarActivity", "Setting notification - Event ID: " + eventId + ", Time: " + notificationTime);
        Intent intent = new Intent(this, AlarmBroadcastReceiver.class);
        intent.putExtra("eventType", "calendarEvent");
        intent.putExtra("eventTitle", event.getTitle());
        intent.putExtra("notificationContent", notificationContent);
        intent.putExtra("eventDate", event.getDate());
        intent.putExtra("eventTime", event.getTime());
        intent.putExtra("notificationId", eventId);

        PendingIntent alarmIntent = PendingIntent.getBroadcast(
                this, eventId, intent, PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, notificationMillis, alarmIntent);
    }

    private void setupAddEventDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.popup_calendar, null);
        builder.setView(dialogView);

        // Find views in the dialog layout
        EditText titleEditText = dialogView.findViewById(R.id.titleEditText);
        Button dateButton = dialogView.findViewById(R.id.dateButton);
        TextView selectedDateTextView = dialogView.findViewById(R.id.selectedDateTextView);

        runOnUiThread(() -> {
            if (selectedDate != null) {
                selectedDateTextView.setText(selectedDate.toString());
            }
        });

        // Add an OnClickListener to open the date picker dialog when dateButton is clicked
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("DatePicker", "Date Button Clicked");
                Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH); // January is 0
                int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        CalendarActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year1, int monthOfYear, int dayOfMonth1) {
                                // Correct the month value by adding 1
                                selectedDate = LocalDate.of(year1, monthOfYear + 1, dayOfMonth1);
                                // Update the TextView with the selected date
                                selectedDateTextView.setText(selectedDate.toString());
                                // Rest of your logic...
                            }
                        }, year, month, dayOfMonth);

                datePickerDialog.show();
            }
        });

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                TimePicker timePicker = dialogView.findViewById(R.id.timePicker);
                String title = titleEditText.getText().toString();
                // Get the selected hour and minute
                int hour = timePicker.getHour();
                int minute = timePicker.getMinute();

                // Format the time as needed (e.g., as HH:mm)
                String formattedTime = String.format(Locale.getDefault(), "%02d:%02d", hour, minute);

                // Save the event data to your Room database with the formatted time
                saveEventToDatabase(title, selectedDate.toString(), formattedTime);
                updateCalendarWithEvents(db.eventDao().getAll());
            }

        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
        updateCalendarWithEvents(db.eventDao().getAll());
    }

    private void saveEventToDatabase(String title, String date, String time) {
        Log.d("CalendarActivity", "Saving event - Title: " + title + ", Date: " + date + ", Time: " + time);
        Event event = new Event();
        event.setTitle(title);
        event.setDate(date);
        event.setTime(time);

        AsyncTask.execute(() -> {
            long eventId = db.eventDao().insert(event);
            event.setId((int) eventId);
            Log.d("CalendarActivity", "Event saved - ID: " + eventId);

            scheduleCalendarEventNotifications(event);

            runOnUiThread(() -> {
                new LoadEventsTask().execute();
            });
        });
        updateCalendarWithEvents(db.eventDao().getAll());
    }
}
