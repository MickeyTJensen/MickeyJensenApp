package com.example.myapp;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class AppNotificationManager {

    private Context context;
    private NotificationManagerCompat notificationManager;

    // Calendar channel information
    private static final String CALENDAR_CHANNEL_ID = "calendar_channel";
    private static final String CALENDAR_CHANNEL_NAME = "Calendar Notifications";
    private static final String CALENDAR_CHANNEL_DESCRIPTION = "Notifications for calendar events";
    private static final String TIMER_CHANNEL_ID = "timer_channel";
    private static final String TIMER_CHANNEL_NAME = "Timer Notifications";
    private static final String TIMER_CHANNEL_DESCRIPTION = "Notifications for timer";
    public static final String REMINDER_CHANNEL_ID = "reminder_channel";
    private static final String REMINDER_CHANNEL_NAME = "Reminder Notifications";
    private static final String REMINDER_CHANNEL_DESCRIPTION = "Notifications for reminder";

    public AppNotificationManager(Context context) {
        this.context = context;
        this.notificationManager = NotificationManagerCompat.from(context);

        // Create the calendar notification channel during initialization
        createCalendarNotificationChannel();
        createTimerNotificationChannel();
        createReminderNotificationChannel();
    }
    public void createNotificationChannel(String channelId, String channelName, String channelDescription) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            channel.setDescription(channelDescription);
            NotificationManager notificationManager = context.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void showNotification(String channelId, int notificationId, String title, String content) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification) // Replace with your icon
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true); // Auto cancel on tap

        // Show the notification
        notificationManager.notify(notificationId, builder.build());
    }

    public void cancelNotification(int notificationId) {
        notificationManager.cancel(notificationId);
    }

    // Methods for showing event notifications

    public void showEventNotification(String title, String date, String time) {
        String channelId = "event_channel"; // Define your event channel ID
        int notificationId = title.hashCode(); // Generate a unique ID

        // Define the event notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification) // Replace with your icon
                .setContentTitle("Event at " + time)
                .setContentText(title + " on " + date)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true); // Auto cancel on tap

        // Show the event notification
        notificationManager.notify(notificationId, builder.build());
    }
    public static String getCalendarChannelId() {
        return CALENDAR_CHANNEL_ID;
    }

    // Methods for showing timer notifications
    public void showTimerNotification(String channelId, int notificationId, String title, String content, PendingIntent dismissIntent) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", dismissIntent);

        notificationManager.notify(notificationId, builder.build());
    }
    private void createCalendarNotificationChannel() {
        CharSequence name = context.getString(R.string.calendar_channel);
        String description = context.getString(R.string.calendar_channel_description);
        createNotificationChannel(CALENDAR_CHANNEL_ID, name.toString(), description);
    }

    private void createTimerNotificationChannel() {
        CharSequence name = context.getString(R.string.timer_channel);
        String description = context.getString(R.string.timer_channel_description);
        createNotificationChannel(TIMER_CHANNEL_ID, name.toString(), description);
    }

    private void createReminderNotificationChannel() {
        CharSequence name = context.getString(R.string.reminder_channel);
        String description = context.getString(R.string.reminder_channel_description);
        createNotificationChannel(REMINDER_CHANNEL_ID, name.toString(), description);
        Log.d("AppNotificationManager", "Creating notification channel: ");

    }

    public void showReminderNotification(String channelId, int notificationId, String title, String content, PendingIntent dismissIntent) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle(title)
                .setContentText(content)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop", dismissIntent);

        notificationManager.notify(notificationId, builder.build());
    }
    public void sendReminderNotification(Context context, int reminderId, String reminderName) {
        Intent dismissIntent = new Intent(context, DismissReceiver.class);
        dismissIntent.setAction("com.example.myapp.ACTION_DISMISS_REMINDER");
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(context, reminderId, dismissIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, REMINDER_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Reminder: " + reminderName)
                .setContentText("It's time for your reminder.")
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Dismiss", dismissPendingIntent); // Assuming you have a drawable ic_dismiss

        notificationManager.notify(reminderId, builder.build());
        Log.d("AppNotificationManager", "Preparing to show notification for Reminder ID: " + reminderId + ", Name: " + reminderName);

    }

}
