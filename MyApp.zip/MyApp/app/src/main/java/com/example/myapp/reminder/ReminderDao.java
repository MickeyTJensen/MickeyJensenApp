package com.example.myapp.reminder;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface ReminderDao {
    @Insert
    long insert(Reminder reminder);

    @Query("SELECT * FROM reminders")
    List<Reminder> getAllReminders(); // Corrected typo here

    @Delete
    void delete(Reminder reminder);

    @Update
    void update(Reminder reminder); // Update method
}
