package com.example.myapp.reminder;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import com.example.myapp.R;

import java.util.List;

public class ReminderAdapter extends ArrayAdapter<Reminder> {
    private Context context;
    private List<Reminder> reminders;
    private OnReminderDeleteListener deleteListener;

    public ReminderAdapter(Context context, List<Reminder> reminders, OnReminderDeleteListener deleteListener) {
        super(context, 0, reminders);
        this.context = context;
        this.reminders = reminders;
        this.deleteListener = deleteListener;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Reminder reminder = getItem(position);
        ViewHolder viewHolder;

        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.reminder_item, parent, false);
            viewHolder.textViewReminder = convertView.findViewById(R.id.reminderText); // Use reminderText TextView
            viewHolder.switchReminder = convertView.findViewById(R.id.isActiveSwitch);
            viewHolder.deleteButton = convertView.findViewById(R.id.deleteButton);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        String daysOfWeek = reminder.getDaysAsString();
        String timeAndDate = " " + reminder.getName() + " " +  reminder.getHour() + ":" + reminder.getMinute() + " " + reminder.getDaysAsString();

        viewHolder.textViewReminder.setText(timeAndDate + " on " + daysOfWeek);
        viewHolder.textViewReminder.setText(timeAndDate); // Set text in reminderText TextView
        viewHolder.switchReminder.setOnCheckedChangeListener(null); // Detach listener temporarily
        viewHolder.switchReminder.setChecked(reminder.isActive());
        viewHolder.switchReminder.setOnCheckedChangeListener((buttonView, isChecked) -> {
            reminder.setActive(isChecked);
            // Update reminder in the database
            ((ReminderActivity) context).handleReminderUpdate(reminder);
        });
        viewHolder.deleteButton.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteReminder(reminder);
            }
        });

        return convertView;
    }


    private static class ViewHolder {
        TextView textViewReminder;
        Switch switchReminder;
        Button deleteButton;
    }

    public interface OnReminderDeleteListener {
        void onDeleteReminder(Reminder reminder);
    }
}
