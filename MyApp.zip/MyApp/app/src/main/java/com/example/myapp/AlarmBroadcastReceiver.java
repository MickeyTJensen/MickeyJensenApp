package com.example.myapp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.example.myapp.mediaplayer.MediaPlayerManager;


public class AlarmBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if ("calendarEvent".equals(intent.getStringExtra("eventType"))) {
            // Extract the details from the intent
            String title = intent.getStringExtra("eventTitle");
            String date = intent.getStringExtra("eventDate");
            String time = intent.getStringExtra("eventTime");
            int notificationId = intent.getIntExtra("notificationId", 0);

            // Create and show the notification
            AppNotificationManager notificationManager = new AppNotificationManager(context);
            notificationManager.showNotification(AppNotificationManager.getCalendarChannelId(),
                    notificationId, title, "Event on " + date + " at " + time);
        }
        else if ("reminderEvent".equals(intent.getStringExtra("eventType"))) {
                // Extract reminder details
                int reminderId = intent.getIntExtra("reminder_id", -1);
                String reminderName = intent.getStringExtra("reminder_name");

                // Create and show the notification
                AppNotificationManager notificationManager = new AppNotificationManager(context);
                String contentText = "Don't forget: " + reminderName;

                // Show the reminder notification
                notificationManager.showReminderNotification(
                        AppNotificationManager.REMINDER_CHANNEL_ID,
                        reminderId,
                        "Reminder: " + reminderName,
                        contentText,
                        null // You can add a PendingIntent here if needed
                );
            } else {
            // Handle other types of alarms/intents as before
            MediaPlayerManager mediaPlayerManager = new MediaPlayerManager(context);
            mediaPlayerManager.playAlarmSound();
            // ... existing notification logic ...
        }
    }
}