package com.example.myapp;

import android.app.Application;

import androidx.room.Room;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

public class MyApp extends Application {
    private AppDatabase db;

    @Override
    public void onCreate() {
        super.onCreate();
        db = Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "my-database-name")
                .addMigrations(MIGRATION_1_2) // Apply your migration here
                .build();
    }
    static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(SupportSQLiteDatabase database) {
            // Define your migration logic here
            // This may involve altering the schema, adding columns, or other necessary changes
            // You need to write SQL statements for this migration
            database.execSQL("ALTER TABLE reminders ADD COLUMN new_column_name INTEGER DEFAULT 0");
        }
    };


    public AppDatabase getDatabase() {
        return db;
    }
}