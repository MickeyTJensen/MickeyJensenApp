package com.example.myapp;

import android.app.Application;

public class MyApp extends Application {
    public static final String CHANNEL_ID = "MickeyJensenApp";

    @Override
    public void onCreate() {
        super.onCreate();
    }
}