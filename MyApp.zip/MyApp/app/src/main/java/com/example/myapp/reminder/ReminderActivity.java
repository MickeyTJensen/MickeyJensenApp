package com.example.myapp.reminder;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.Toast;
import android.Manifest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.room.Room;

import com.example.myapp.AppDatabase;
import com.example.myapp.AppNotificationManager;
import com.example.myapp.DismissReceiver;
import com.example.myapp.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class ReminderActivity extends AppCompatActivity implements ReminderAdapter.OnReminderDeleteListener {
    // UI Components
    private NumberPicker hourPicker, minutePicker;
    private CheckBox[] dayCheckboxes = new CheckBox[7]; // Sun = 0, Mon = 1, ..., Sat = 6
    private CheckBox checkboxMorning, checkboxOneHourBefore;
    private EditText editTextReminderName;
    private Button addButton, resetButton;
    private ListView remindersListView;
    private AppNotificationManager notificationManager;
    private static final int REQUEST_CODE_PERMISSION = 234;

    // Data
    private List<Reminder> reminders;
    private ReminderAdapter adapter; // Assuming you've defined this adapter

    // Database
    private AppDatabase db; // Your Room database

    private boolean isNewReminderAdded = false; // Flag to track newly added reminders

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder);

        initializeUIComponents();
        initializeDatabase();
        notificationManager = new AppNotificationManager(this); // Initialize your notification manager here
    }

    private void initializeDatabase() {
        AsyncTask.execute(() -> {
            db = Room.databaseBuilder(getApplicationContext(),
                    AppDatabase.class, "database-name").build();
            loadReminders();
        });
    }

    private void initializeUIComponents() {
        hourPicker = findViewById(R.id.hourPicker);
        minutePicker = findViewById(R.id.minutePicker);
        editTextReminderName = findViewById(R.id.editTextReminderName);
        addButton = findViewById(R.id.addButton);
        resetButton = findViewById(R.id.resetReminderButton);
        remindersListView = findViewById(R.id.remindersListView);
        checkboxMorning = findViewById(R.id.checkbox_7am);
        checkboxOneHourBefore = findViewById(R.id.checkbox_1h);

        hourPicker.setMaxValue(23);
        hourPicker.setMinValue(0);
        minutePicker.setMaxValue(59);
        minutePicker.setMinValue(0);

        // Initialize day checkboxes
        String[] days = {"mon", "tue", "wed", "thu", "fri", "sat", "sun"};
        for (int i = 0; i < 7; i++) {
            int resId = getResources().getIdentifier("checkbox_" + days[i], "id", getPackageName());
            dayCheckboxes[i] = findViewById(resId);
        }

        reminders = new ArrayList<>();
        adapter = new ReminderAdapter(this, reminders, this);
        remindersListView.setAdapter(adapter);

        addButton.setOnClickListener(v -> addReminder());
        resetButton.setOnClickListener(v -> resetReminders());
    }

    private void addReminder() {
        String reminderName = editTextReminderName.getText().toString().trim();
        if (reminderName.isEmpty()) {
            Toast.makeText(this, "Please enter a reminder name.", Toast.LENGTH_SHORT).show();
            return;
        }

        Calendar calendar = Calendar.getInstance();
        int hour = hourPicker.getValue();
        int minute = minutePicker.getValue();

        if (checkboxMorning.isChecked()) {
            hour = 7; // Set hour for "Every Morning"
            minute = 0; // Set minute for "Every Morning"
        }

        // Adjust for "1 Hour Before"
        if (checkboxOneHourBefore.isChecked()) {
            calendar.set(Calendar.HOUR_OF_DAY, hour);
            calendar.set(Calendar.MINUTE, minute);
            calendar.add(Calendar.HOUR_OF_DAY, -1);
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minute = calendar.get(Calendar.MINUTE);
        }

        boolean[] daysArray = new boolean[7];
        for (int i = 0; i < dayCheckboxes.length; i++) {
            daysArray[i] = dayCheckboxes[i].isChecked();
        }
        String daysString = Reminder.convertDaysArrayToString(daysArray);

        Reminder newReminder = new Reminder(0, hour, minute, daysString, checkboxMorning.isChecked(), checkboxOneHourBefore.isChecked(), reminderName, true);
        saveReminder(newReminder);

        isNewReminderAdded = true; // Set the flag
    }

    private void scheduleReminder(Reminder reminder) {
        // Check if the permission is needed and granted
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && checkSelfPermission(Manifest.permission.SCHEDULE_EXACT_ALARM) != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted, request it
            requestPermissions(new String[]{Manifest.permission.SCHEDULE_EXACT_ALARM}, REQUEST_CODE_PERMISSION);
        } else {
            // Permission is granted or not needed, proceed with scheduling the reminder
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            boolean[] daysArray = reminder.getDaysArray();

            // Correct way to set the time zone to Stockholm
            TimeZone timeZone = TimeZone.getTimeZone("Europe/Stockholm");
            Calendar calendar = Calendar.getInstance(timeZone);

            for (int i = 0; i < daysArray.length; i++) {
                if (!daysArray[i]) {
                    continue; // Skip days not set for reminder
                }

                // Set the reminder time based on local time zone
                calendar.setTimeInMillis(System.currentTimeMillis()); // Reset calendar to current time
                calendar.set(Calendar.HOUR_OF_DAY, reminder.getHour());
                calendar.set(Calendar.MINUTE, reminder.getMinute());
                calendar.set(Calendar.SECOND, 0);
                calendar.set(Calendar.MILLISECOND, 0);

                // Adjust for "1 Hour Before" if necessary
                if (reminder.isOneHourBefore()) {
                    calendar.add(Calendar.HOUR_OF_DAY, -1);
                }

                // Adjust the calendar to the next occurrence of the day
                adjustCalendarForReminderDay(calendar, i, reminder.isOneHourBefore());

                // No need for manual DST adjustment as Calendar handles it based on time zone

                Intent intent = new Intent(this, ReminderReceiver.class);
                intent.setAction("YOUR_REMINDER_ACTION");
                intent.putExtra("reminder_id", reminder.getId());
                intent.putExtra("reminder_name", reminder.getName());
                intent.putExtra("scheduled_hour", reminder.getHour());
                intent.putExtra("scheduled_minute", reminder.getMinute());

                // Ensure unique request code for the PendingIntent to prevent overwriting
                int requestCode = (reminder.getId() * 10) + i; // Example to make it unique
                PendingIntent alarmIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_IMMUTABLE);

                // Use setExact() for precise timing
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), alarmIntent);

                // Logging with corrected time zone display
                SimpleDateFormat dateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy", Locale.ENGLISH);
                dateFormat.setTimeZone(timeZone); // Ensure formatter uses correct time zone
                Log.d("ReminderActivity", "Scheduled reminder: " + reminder.getName() + " at " + dateFormat.format(calendar.getTime()));
            }
        }
    }


    private void scheduleReminderNotification(int reminderId, long notificationMillis, String notificationContent, Reminder reminder) {
        Log.d("ReminderActivity", "Setting notification - Reminder ID: " + reminderId + ", Time: " + notificationMillis);

        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.setAction("YOUR_REMINDER_ACTION");
        intent.putExtra("reminder_id", reminder.getId());
        intent.putExtra("reminder_name", reminder.getName());

        PendingIntent alarmIntent = PendingIntent.getBroadcast(this, reminderId, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, notificationMillis, alarmIntent);
    }

    private void adjustCalendarForReminderDay(Calendar calendar, int dayOfWeekIndex, boolean isOneHourBefore) {
        int currentDayOfWeek = calendar.get(Calendar.DAY_OF_WEEK) - 1; // Convert to 0-based index (Sun = 0)
        int daysUntilNext = (dayOfWeekIndex - currentDayOfWeek + 7) % 7;

        if (daysUntilNext == 0) { // Today is the reminder day
            if (calendar.getTimeInMillis() <= System.currentTimeMillis()) { // If reminder time has passed for today
                daysUntilNext = 7; // Set for next week
            }
        }

        calendar.add(Calendar.DAY_OF_YEAR, daysUntilNext);

        // If adjusting for "1 Hour Before" caused the day to change, this is handled by initially subtracting the hour
    }

    private void loadReminders() {
        AsyncTask.execute(() -> {
            List<Reminder> loadedReminders = db.reminderDao().getAllReminders();
            Log.d("ReminderActivity", "Loaded " + loadedReminders.size() + " reminders"); // Log statement
            runOnUiThread(() -> {
                reminders.clear();
                reminders.addAll(loadedReminders);
                adapter.notifyDataSetChanged();
                // Reschedule all active reminders
                for (Reminder reminder : loadedReminders) {
                    if (reminder.isActive()) {
                        scheduleReminder(reminder);
                    }
                }
            });
        });
    }
    private void sendReminderNotification(Reminder reminder) {
        Intent dismissIntent = new Intent(this, DismissReceiver.class); // Assuming DismissReceiver is correctly implemented
        dismissIntent.setAction("com.example.myapp.ACTION_DISMISS_REMINDER");
        PendingIntent dismissPendingIntent = PendingIntent.getBroadcast(this, reminder.getId(), dismissIntent, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_IMMUTABLE);

        notificationManager.showReminderNotification(
                AppNotificationManager.REMINDER_CHANNEL_ID,
                reminder.getId(),
                "Reminder: " + reminder.getName(),
                "It's time for your reminder.", // You can customize this message
                dismissPendingIntent // Optionally pass the dismiss intent
        );

        // Log to track notification
        Log.d("ReminderActivity", "Sent notification for reminder: " + reminder.getName());
    }
    @Override
    public void onDeleteReminder(Reminder reminder) {
        AsyncTask.execute(() -> {
            db.reminderDao().delete(reminder);
            cancelReminder(reminder);
            Log.d("ReminderActivity", "Deleting reminder: " + reminder.getName());

            runOnUiThread(() -> {
                reminders.remove(reminder);
                adapter.notifyDataSetChanged();
            });
        });
    }

    public void handleReminderUpdate(Reminder reminder) {
        AsyncTask.execute(() -> {
            db.reminderDao().update(reminder);
            Log.d("ReminderActivity", "Updating reminder: " + reminder.getName());

            runOnUiThread(() -> {
                if (reminder.isActive()) {
                    scheduleReminder(reminder);
                    Log.d("ReminderActivity", "Rescheduling reminder: " + reminder.getName());
                } else {
                    cancelReminder(reminder);
                    Log.d("ReminderActivity", "Cancelling reminder: " + reminder.getName());
                }
            });
        });
    }

    private void resetReminders() {
        AsyncTask.execute(() -> {
            for (Reminder reminder : reminders) {
                cancelReminder(reminder);
                // Delete the reminder from the database
                db.reminderDao().delete(reminder);
                Log.d("ReminderActivity", "Cancelling scheduled reminder and deleting from database: " + reminder.getName());
            }
            reminders.clear();
            runOnUiThread(() -> {
                adapter.notifyDataSetChanged();
                Log.d("ReminderActivity", "Reset all reminders");
            });
        });
    }

    private void cancelReminder(Reminder reminder) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        boolean[] daysArray = reminder.getDaysArray();

        for (int i = 0; i < daysArray.length; i++) {
            if (daysArray[i]) {
                int requestCode = reminder.getId() * 10 + i;
                Intent intent = new Intent(this, ReminderReceiver.class);
                PendingIntent alarmIntent = PendingIntent.getBroadcast(this, requestCode, intent, PendingIntent.FLAG_IMMUTABLE);
                alarmManager.cancel(alarmIntent);
                Log.d("ReminderActivity", "Cancelling alarm for: " + reminder.getName() + " on day " + (i + 1));
            }
        }
    }

    private void saveReminder(Reminder reminder) {
        AsyncTask.execute(() -> {
            long reminderId = db.reminderDao().insert(reminder);
            reminder.setId((int) reminderId);
            runOnUiThread(() -> {
                reminders.add(reminder);
                adapter.notifyDataSetChanged();
                // Prepare data for scheduling the notification
                Calendar notificationTime = Calendar.getInstance();
                // Assume your Reminder object has methods to get the necessary time info
                // You might need to adjust the following lines according to your Reminder class structure
                notificationTime.set(Calendar.HOUR_OF_DAY, reminder.getHour());
                notificationTime.set(Calendar.MINUTE, reminder.getMinute());
                String notificationContent = "It's time for your reminder: " + reminder.getName();
                // Now schedule the notification
                scheduleReminderNotification(reminder.getId(), notificationTime.getTimeInMillis(), notificationContent, reminder);
            });
        });
    }
    private void sendScheduledReminderNotification(Reminder reminder) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        String channelId = "reminder_channel_id"; // Ensure this channel is created in your application

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(R.drawable.ic_notification) // adjust this to your icon
                .setContentTitle("Reminder")
                .setContentText(reminder.getName())
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        // If using Android Oreo and above, don't forget to create the notification channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, "Reminders", NotificationManager.IMPORTANCE_HIGH);
            notificationManager.createNotificationChannel(channel);
        }

        notificationManager.notify(reminder.getId(), builder.build());
    }
    // Request the permission when needed, for example, in an onClickListener
    private void requestPermissionAndScheduleReminder(Reminder reminder) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            // Request the SCHEDULE_EXACT_ALARM permission
            requestPermissions(new String[]{Manifest.permission.SCHEDULE_EXACT_ALARM}, REQUEST_CODE_PERMISSION);
        } else {
            // The permission is not needed for older Android versions
            // You can proceed with scheduling the reminder
            scheduleReminder(reminder);
        }
    }

    // Handle the permission request result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed with scheduling the reminder
                if (isNewReminderAdded) {
                    Reminder newReminder = reminders.get(reminders.size() - 1);
                    scheduleReminder(newReminder);
                }
            } else {
                // Permission denied, handle accordingly (e.g., show a message to the user)
                // You may also provide an option to manually enable the permission from settings
            }
        }
    }
}
